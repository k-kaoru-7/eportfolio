from django.apps import AppConfig


class AccountManagementConfig(AppConfig):
    name = 'account_management'
