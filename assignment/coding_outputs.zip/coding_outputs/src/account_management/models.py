from django.db import models

# Create your models here.

'''
This model describes customer information
'''
class Customer(models.Model):
    id = models.CharField(primary_key=True, max_length=8)
    name = models.BinaryField()
    address = models.BinaryField()
    phone_number = models.BinaryField()

'''
This model describes bank account information of the customer.
Account is related to Customer with customer_id.
A customer is able to have more than one account.
'''
class Account(models.Model):
    account_number = models.CharField(primary_key=True, max_length=7)
    customer_id = models.ForeignKey(Customer, on_delete=models.CASCADE)

'''
This model describes bank account information of a specified customer.
Account is related to Customer with customer_id.
A customer is able to have more than one account.
'''
class AccountActivity(models.Model):
    account_number = models.ForeignKey(Account, on_delete=models.CASCADE)
    detail_number = models.IntegerField()
    transaction_amount = models.FloatField()
    transaction_datetime = models.DateTimeField()
    balance = models.FloatField()

    # This defines the unique constraint of AccountActivity
    class Meta:
        unique_together = (('account_number', 'detail_number'),)
