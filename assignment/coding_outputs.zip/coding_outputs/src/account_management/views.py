from django.shortcuts import render
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from django.db import IntegrityError
from django.core.exceptions import ValidationError
from django.contrib import messages
from cryptography.fernet import Fernet
from .forms import CustomerForm
from .models import Customer, Account, AccountActivity
from .const import key


'''
This view function renders Top page of Bank Account Management System.
'''
def index(request):
    return render(request, 'index.html')

'''
This view function shows CustomerForm to register a new customer.
This is called to render Customer Register page.
'''
def showCustomerForm(request):
    # Create a instance of CustomerForm
    form = CustomerForm()
    # Set form in context 
    context = {
        'customerForm':form,
    }
 
    return render(request, 'register.html', context)


'''
This view function retrieves whole customer data from Customer table and renders Customer List page.
'''
def listCustomer(request):
    # Retrieve whole customer data from Customer table
    data = Customer.objects.all()

    # Create a blank list to set the account information
    customer_list = []
    # Create cipher object with a key defined in const.py
    f = Fernet(key)
    # In this loop, account information in each record is appended to the account_list
    for customer in data:
        id = customer.id
        # Decrypt the customer's name
        name = f.decrypt(customer.name).decode('utf-8')
        # Decrypt the customer's address
        address = f.decrypt(customer.address).decode('utf-8')
        # Decrypt the customer's phone number
        phone_number = f.decrypt(customer.phone_number).decode('utf-8')

        # Append to the list
        customer_list.append({'id':id, 'name': name, 'address': address, 'phone_number': phone_number})

    # Set retrieved data in context
    context = {'message': 'List of Customer', 'data': customer_list}

    print(context)

    return render(request, 'list_customer.html', context)

'''
This view function adds input values in CustomerForm into Customer table in DB.
'''
def addCustomer(request):
    
    # Checking request method
    # If it is POST method, validate the form and register data into DB
    if request.method == 'POST':
        # Create an instance of CustomerForm using input values
        customerForm = CustomerForm(request.POST)
        # Validate input values
        if customerForm.is_valid():
            # The below is encryption process
            # The Customer's name, address and phone number are encrypted
            # Get values from customerForm
            print(customerForm.cleaned_data)
            name = customerForm.cleaned_data['name']
            address = customerForm.cleaned_data['address']
            phone_number = customerForm.cleaned_data['phone_number']
            # Create cipher object with a key defined in const.py
            f = Fernet(key)
            # Encrypt each field with cipher object
            token_name = f.encrypt(name.encode())
            token_address = f.encrypt(address.encode())
            token_phone = f.encrypt(phone_number.encode())

            # Create Customer Model instance
            customer = Customer(
                id=customerForm.cleaned_data['id'], 
                name=token_name, 
                address=token_address, 
                phone_number=token_phone,
            )

            try:
                # Insert into DB
                customer.save(force_insert=True)
            except IntegrityError as e:
                # Exception process
                # If unique constraint failure occurs, raise error with a message below. 
                if 'UNIQUE constraint' in e.args[0]:
                    messages.error(request, 'The customer id has been already used. Please use other values.')
                # If other failure occurs, raise error with a message below. 
                else:
                    messages.error(request, 'A DB access error occurred. Please contact an administrator.')

                # Set form error in context again here to send back to Register Customer page
                customerForm = CustomerForm(request.POST)
                context = {
                    'customerForm': customerForm,
                }

                # Render Register Customer page with an error message.
                return render(request, 'register.html',context)
                 
        else:
            print("Valudation error")
            # Set form error in context
            context = {
                'customerForm':customerForm,
            }

            # Render Register Customer page with validation error messages.
            return render(request, 'register.html',context)
 
    # Redirect to Top page 
    return render(request, 'index.html')

'''
This is a Class-based view to delete a specified customer.
This is related to Customer model.
The record of the specificed customer is deleted based on the request from Customer List page.
'''
class CustomerDeleteView(DeleteView):
    # Set Customer as a model
    model = Customer
    # Back to Customer List page once deletion succeeds 
    success_url = reverse_lazy("account_management:listCustomer")


'''
This view function retrieves Account data from Account table and render Account List page.
There are two types of retrieving account list.
Whole account list mode : This retrieves all account data.
 Whole account list mode is used for the screen transition from Top page. 
Specified account list mode : This retrieves specified account data related to customer_id. 
 Specified account list mode is used for the screen transition from Customer List page.
'''
def listAccount(request, target_customer_id):
    if target_customer_id == 'all':
        # Join Account and Customer table with customer_id, and retrieve whole data.
        data = Account.objects.select_related('customer_id').all()
    else:
        # Join Account and Customer table with customer_id, and retrieve whole data.
        data = Account.objects.filter(customer_id=target_customer_id).select_related('customer_id').all()

    # Create a blank list to set the account information
    account_list = []
    # Create cipher object with a key defined in const.py
    f = Fernet(key)
    # In this loop, account information in each record is appended to the account_list
    for account in data:
        account_number = account.account_number
        customer_id = account.customer_id.id
        # Decrypt the customer's name
        customer_name = f.decrypt(account.customer_id.name).decode('utf-8')

        # Append to the list
        account_list.append({'account_number':account_number, 'customer_id': customer_id, 'customer_name': customer_name})

    # Set formatted data in context
    context = {
        'message': 'List of Account', 
        'data': account_list,
        'customer_id': target_customer_id
    }

    return render(request, 'list_account.html', context)

'''
This view function retrieves Account data from Account table and render Account List page.
There are two types of retrieving account list.
Whole account list mode : This retrieves all account data.
 Whole account list mode is mainly used for the screen transition from Top page. 
Specified account list mode : This retrieves specified account data related to customer_id. 
 Specified account list mode is mainly used for the screen transition from Customer List page.
'''
def showAccountActivity(request, account_number, target_customer_id):
    print("Detail.get_context_data")
    # Get primary key to retrieve data
    print(account_number)

    # Retrieve the whole account activity list ordering by transaction_datetime desc
    account_activity = AccountActivity.objects.filter(account_number_id=account_number).order_by('transaction_datetime').reverse().all()

    # Retrieve account information
    account = Account.objects.filter(account_number=account_number).select_related('customer_id').first()

    # Decrypt the customer's name
    f = Fernet(key)
    customer_name = f.decrypt(account.customer_id.name).decode('utf-8')

    # Set customer_id, customer_name and account_activity in context
    context = {
        'message': 'List of Account Activity',
        'customer_id' : account.customer_id.id,
        'customer_name' : customer_name,
        'data': account_activity,
        'target_customer_id' : target_customer_id
    }

    return render(request, './detail_account.html', context)

