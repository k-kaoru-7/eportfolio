from django.urls import path
from . import views

app_name = 'account_management'

urlpatterns = [
    # Show Top page
    path('account_management/', views.index, name='index'),
    # Show Form page to register a customer
    path('account_management/register', views.showCustomerForm, name='register'),
    # Add a customer
    path('account_management/add', views.addCustomer, name='addCustomer'),
    # List customers
    path('account_management/list_customer', views.listCustomer, name='listCustomer'),
    # Delete a customer
    path('account_management/delete/<str:pk>',  views.CustomerDeleteView.as_view(), name="delete_customer"),
    # List accounts
    path('account_management/list_account/<str:target_customer_id>', views.listAccount, name='listAccount'),
    # Show account activities
    path('account_management/detail_account/<str:account_number>/<str:target_customer_id>', views.showAccountActivity, name='detail_account'),
]
