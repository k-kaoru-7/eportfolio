from django import forms
from django.core.validators import MinLengthValidator
from django.core.exceptions import ValidationError

'''
This is a form class to register a new customer.
The field in the form is the followings:
 id : the customer id which is a primary key, 8 characters and required item.
 name : the customer's name, 100 characters at maximum and required item.
 address : the customer's address, 100 characters at maximum and required item.
 phone_number : the customer's phone number, 15 numbers at maximum and required item.
'''
class CustomerForm(forms.Form):
    # Define attribute
    id = forms.CharField(label=u'id', max_length=8, required=True)
    name = forms.CharField(label=u'name', max_length=100, required=True)
    address = forms.CharField(label=u'address', max_length=100, required=True)
    phone_number = forms.CharField(label=u'phone_number', max_length=15, required=True)

    class Meta:
        fields = ["id", "name", "address", "phone_number"]

    # Define additional validator and placeholder
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Placeholder for id
        self.fields['id'].widget.attrs = {'placeholder': 'Enter 8 digits of number'}
        # Define MinLengthValidator for id since it should be always 8 charactes
        self.fields['id'].validators = [MinLengthValidator(8, 'This value should be 8 characters')]
        # Placeholder for name
        self.fields['name'].widget.attrs = {'placeholder': 'Enter full name'}
        # Placeholder for address
        self.fields['address'].widget.attrs = {'placeholder': 'Enter whole address'}
        # Placeholder for phone_number
        self.fields['phone_number'].widget.attrs = {'placeholder': 'Enter number without -'}

    '''
    This method validates the phone number field.
    Only number is available.
    '''
    def clean_phone_number(self):
        phone_number = self.cleaned_data.get("phone_number")
        print(phone_number)
        if phone_number.isdigit()==False:
            print("Phone Number Check Error")
            raise ValidationError('This values should be numbers')

        return phone_number
