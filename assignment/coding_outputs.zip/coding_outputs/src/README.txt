* Overview of the project
This project contains coding outputs of the Bank Account Management System.
All programmes are written in Python files. A DB file holding data and some test data are included in the project.
Django is applied to the project as a framework for the web application. Security measures are taken to protect data treated in the application.
See below for the detail.

* Summary of functions
The Bank Account Management System manages customer information and also the customer’s bank account information. It enables operators to check the customer information holding bank accounts and the account’s activities
.
There are five pages in the Bank Account Management System.

- Top
- Register Customer
- Customer List
- Bank Account List
- Bank Account Activity List

 <Top>
 This is an index of the web application. The link to every page on the application is displayed as a main menu on this page.

 <Register Customer>
 Operators can register a new customer information who holds the bank’s account on this page. The following attributes can be recorded.

 Customer’s ID
  A eight characters of code to identify the customer.
 Customer’s name
  The customer’s full name. It allows to enter a hundred characters at a maximum.   
 Customer’s address
  The customer’s full address. It allows to enter a hundred characters at a maximum.   
 Customer’s phone number
  The customer’s phone number without ‘-’. It allows to enter 15 numbers at a maximum.   

 The personal information is sensitive. Hence, customers’ name, address and phone number are encrypted when inserting into a database.

 <Customer List>
  The list of customers’ information registered on Register Customer page can be shown on this page. The fields described in the Register Customer section above are displayed in the list. Encrypted fields, such as a name, an address and a phone number, are decrypted when showing on this page. See Security measures section for the detail.  
  It is available to move from this page to Account Account List page.


 <Bank Account List>
  The list of bank accounts can be shown through this page. The following fields is included in the bank account list.

  Account number
   A seven digit number to identify the bank account.
  Customer’s ID
   The ID of the customer holding the bank account.
  Customer’s name
   The name of the customer holding the bank account.

  Operators can move this page to Bank Account Activity page by clicking the detail button displayed in a row for the bank account.

 <Bank Account Activity List>
  This page shows the history of the account’s activities selected on Bank Account List page. The following fields are displayed.
 
  Customer’s ID
   The ID of the customer holding the bank account.
  Customer’s name
   The name of the customer holding the bank account.
  Account number
   The account number of the bank account.
  Transaction datetime
   The date and the time that deposits or withdrawals are done.
  Transaction amount
   The amount of the deposit or the withdrawal.
  Balance
   The balance after the account’s activity is conducted.
 
  The list of the the account’s activities are displayed in descending order by using the transaction datetime field. 

* Design Concept
 This section indicates the design concept in each area, Web application, Web server and database.

 <Web application>
 Django is applied to this web application. It is designed and implemented based on the principles of the Django framework, which is Django MTV Architecture as below.

 - Model
  It describes logical data structure treated on the web application. Each class in Model is related to a table in a database. This definition is migrated into a database as a schema.

 - Template
  This is a presentation layer to display a page on a web browser. It consists of html files by each page. 

 - View
  The logic to retrieve and format data is defined in View. View accesses Model classes and renders Template. 

 Django is a full specification framework compared to Flask, which has various functions including security measures. This is why Django has been selected as a web application in this project.

 <Web server>
 Nginx is used as a web server. Nginx processes a large amount of data in a single thread with a high performance. This is the reason why Nginx is applied to the project. 

 <Database>
 SQLite is used as a database, considering efficiency in the development from the perspective of two reasons below. 

 - SQLite are included in the Django framework as a default databa7se. 
 - A complete database is stored in a single cross-platform disk file(SQLite, N.D.), which is easy to migrate.

 <Security measures>
 SSL/TLS and DB encryption are applied to the project to protect sensitive data. See Security measures section for the detail.

* Project Structure
 This section explains the structure of the project.

root
├── account_management/
│   ├── migrations/
│   ├── templates/
│   │   ├── base_account_management..html
│   │   ├── index.html
│   │   ├── register.html
│   │   ├── delete_customer.html
│   │   ├── list_customer.html
│   │   ├── list_account.html
│   │   └── detail_account.html
│   ├── test/
│   │   ├── account_data.csv
│   │   └── account_activity_data.csv
│   ├── __init__.py
│   ├── admin.py
│   ├── apps.py
│   ├── const.py
│   ├── forms.py
│   ├── models.py
│   ├── urls.py
│   └── views.py
├── account/
├── static/
├── db.sqllite3
├── manage.py
├── requirements.txt
└── README.txt

 The below is explanation of each directory and file.

 - account_management
  This is an application project directory of Bank Account Management System. It contains all scripts which implements functions Bank Account Management System. Common files or a database file are deployed under the root directory. 

 - migrations
 A directory to manage migration files to migrate a database used in the web application. 

 - templates
 A directory to manage templates html files. Each html file define the presentation of each page. The following is description of each template.
   - base_account_management..html
   A base html file included in all other html. It define information displayed in the header are in every page.
   - index.html
   A html file to display Top page.
   - register.html
   A html file to display Register Customer page.
   - delete_customer.html
   A html file to display Delete Customer modal.
   - list_customer.html
   A html file to display Customer List page.
   - list_account.html
   A html file to display Account List page.
   - detail_account.html
   A html file to display Bank Account Activity List page.

 - test
 This directory contains all test data used to conduct testing for the web application. The file format is csv. The data in csv files is to inserted into a database and verification is conducted by using the data. 

 - admin.py
 A Python file to describe management screen for the web application but it is not used in the project.

 - app.py
 A Python file to describe the application name. The name is referred from other components in the project. The application name is ‘account_management’

 - const.py
 This includes a constant variable describing binary data to be used as a key for DB encryption and decryption. Please see Security measures section for the detail. 

 - forms.py
 A python file to define a form class to be displayed on Register Customer page. 

 - models.py
 A python file to define Model classes. These model classes is related to a table definition in the database and are used when migrating a database. 

 - urls.py
 A python file to describes a mapping between URL path and View. This URL is referred in Template and View. 

 - views.py
 A python file to define View classes. There are two types of View. One is a class-based view and another is a view function. One of these is defined depending on the usage of the view. 

 - account
 An application for login. To Banker Account Management System. 

 - static
 Static files. 

 - db.sqlite3
 A cross-platform disk file which stores a completed database including inserted data. 

 - manage.py
 A Python file to run the web application or migrate the database. 

 - requirement.txt
 All libraries used in the application are listed. Please use this file when establishing an environment to run the application. 

* Description of components
 This section describes components of the application. As mentioned in Design concept section, the Django framework is applied to this project. There are mainly four categories in components, Model, View, Template and Form. The below is the description of classes defined in each component.

 <Model>
 - Customer
  A class which describes customer information. This class is migrated into a database as ‘account_management_customer’ table. 
 - Account
  A class which describes bank account information of a specified customer. Account class is related to Customer with customer_id . A customer is able to hold more than one account.This class is migrated into a database as ‘account_management_account’ table. 
 - AccountActivity
  A class which describes the bank account activity. Account class is related to Customer with customer_id. AccountActivity is related to Account with account_number.There may be more then one records to a bank account. This class is migrated into a database as ‘account_management_accountactivity’ table. 
 
 <View>
 Either a view function or a class-based view is selected depending on how it can be implemented efficiently. Most of views are implemented as a view function. A view which does not need a logic is implemented as a class-based view.

 - index
  A view function to render Top page.
 - showCustomerForm
  A view function to render Register Customer page. It creates an instance of CustomerForm class and send it to a template of Register Customer page.
 - addCustomer
  A view function to add a customer information into ‘account_management_customer’ table in the database. Customer’s name, address and phone number are encrypted in this function when inserting into the database. Once inserting succeeds, it redirects a template to Top page. In addition, values in CustomerForm are validated in this function. If there is any errors in values, it renders Register Customer page with error messages. After 
 - CustomerDeleteView
  A class-based view to delete specified customer information.
 - listCustomer
  A view function to render Customer List page. Encrypted data in Customer model is decrypted in this function before rendering Custome List page.
 - listAccount
  A view function to render Bank Account List page. There are two types of retrieving account list depending on the source page when accessing this view.
Whole account list mode : This retrieves all account data, which is used for the screen transition from Top page. 
Specified account list mode : This retrieves specified account data related to customer_id, which is used for the screen transition from Customer List page.
 - showAccountActivity
  A view function to render Bank Account Activity List page. 

 <Template>
  A template html is created by each page. Please see Project structure section for the detail of templates.

 <Form>
  CustomerForm class is defined to be used as a input form to register a customer. The field in the form is the followings:

 - id : Required field, 8 characters at a minimum or a maximum. 
 - name : Required field, 100 characters at a maximum.
 - address : Required field, 100 characters at a maximum.
 - phone_number : Required field, 15 digit number. 

 These are the same fields as the Customer model. Validation is applied to values in each field. 
 
* Security measures
 The following security measures are implemented to protect data.

 - SSL/TSL
  SSL/TSL is applied to all transactions between web browsers and a web server. The certification issued by Let’s Encrypt is used. All request to HTTP port is redirect to SSL port by the Django framework. This is implemented by set ‘SECURE_SSL_REDIRECT’ True in setting.py as below.

  SECURE_SSL_REDIRECT = True

 - DB Encryption
  Sensitive information, such as Customers’ name, address and phone number, are encrypted when inserting into a database. Encrypted data are decrypted when displaying on pages. AES algorithm is applied to encryption. Cryptography, which is a high-level library for encryption, is used. This library enables to implement encryption and decryption in a easy way as below.  

>>> from cryptography.fernet import Fernet
>>> key = Fernet.generate_key()
>>> key
b'RguEWlPsq-A9MxQLb9FbFePV16d_DtTa0o4HKklhPvc='
>>> f = Fernet(key)
>>> token = f.encrypt(b"Target data")
>>> token
b'gAAAAABe3y1OEs7h9_uuvBUau6BHSa_yef_5Ac0v75yZ2R_FZpEyc-7GJG2nOlZRngINF74dMqLnMG3MEPO0pHsBLqKDQc0MCw=='
>>> f.decrypt(token)
b'Target data'

* Usage
 - How to install the application
  $ pip install -r requirements.txt

 - How to migrate a database
  Make a migration file firstly.
  $ python manage.py makemigrations account_management
  Execute migration.
  $ python manage.py migrate account_management

 - How to run the application on a development environment
  Firstly, it is necessary to set SECURE_SSL_REDIRECT False in setting.py not to redirect to SSL port when sending a request to a development server. Please see Security measures section.
  In the next, run the application with a command below.
  $ python manage.py runserver

  Access http://127.0.0.1:8000/ with a browser.

* Libraries
 Please see requirements.txt. It lists all libraries which are used in the application. 

* Future plan
 Currently, account information and account activities are imported into a database manually. In the future, the data will be linked from the banking system.

* Contact
Kaoru Kitamura
University’s email address : kk21053@essex.ac.uk