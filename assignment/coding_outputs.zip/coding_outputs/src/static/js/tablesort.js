$(document).ready(function() {
  $("#cur_sum").tablesorter({
    headers: {
      0: { sorter: false },
      11: { sorter: false }
    }
  });
})