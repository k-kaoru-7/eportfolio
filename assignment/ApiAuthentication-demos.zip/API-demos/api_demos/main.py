from flask import Flask
from flask_jwt import jwt_required, current_identity, JWT
from datetime import timedelta

app = Flask(__name__)

from .route.auth import auth_blueprint
app.register_blueprint(auth_blueprint)

from .route.sensor import sensor_blueprint
app.register_blueprint(sensor_blueprint)

# JSONのソートを抑止
app.config['JSON_SORT_KEYS'] = False
# Flask JWT
app.config['JWT_SECRET_KEY'] = 'super_secret'      # JWTに署名する際の秘密鍵
app.config['JWT_ALGORITHM'] = 'HS256'                       # 暗号化署名のアルゴリズム
app.config['JWT_LEEWAY'] = 0                                # 有効期限に対する余裕時間
app.config['JWT_EXPIRATION_DELTA'] = timedelta(seconds=300) # トークンの有効期間
app.config['JWT_NOT_BEFORE_DELTA'] = timedelta(seconds=0)   # トークンの使用を開始する相対時間
app.config['JWT_AUTH_URL_RULE'] = '/auth'                   # 認証エンドポイントURL
from .route.auth import authenticate, identity
jwt = JWT(app, authenticate, identity)                       # ここで上記2つの関数を指定

if __name__ == '__main__':
    app.run(debug=True)