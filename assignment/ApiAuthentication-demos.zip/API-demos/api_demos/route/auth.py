from flask import Blueprint, request, jsonify
from hmac import compare_digest

auth_blueprint = Blueprint('auth', __name__, url_prefix='/auth')

# データベースの代わり
class User(object):
    def __init__(self, id, fName, sName, password):
        self.id = id
        self.username = fName
        self.sName = sName

    def __str__(self):
        return "User(id='%s')" % self.id


users = [
    User('UID0001', 'Windsor', 'Elizabeth', 'password'),
]

username_table = {u.username: u for u in users}
userid_table = {u.id: u for u in users}


usersData = {
    'users': [
        {
            'userId': 'UID0001',
            'userName': 'Admin',
            'ldapAccount': 'Admin',
            'fName': 'Windsor',
            'sName': 'Elizabeth',
        }
    ]
}


@auth_blueprint.route('/', methods=['POST'])
def login():

    res = usersData

    return jsonify(res), 200


def authenticate(userId, password):
    user = userid_table.get(userId, None)
    if user and compare_digest(user.password.encode('utf-8'), password.encode('utf-8')):
        return user


def identity(payload):
    user_id = payload['identity']
    return userid_table.get(user_id, None)