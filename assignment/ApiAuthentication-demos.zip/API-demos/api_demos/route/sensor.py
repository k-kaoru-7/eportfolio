from flask import Flask, request, Blueprint, jsonify

app = Flask(__name__)

sensor_blueprint = Blueprint('sensor', __name__, url_prefix='/sensor')

# エンドポイント http:/host/api/users, GETメソッドのみ受け付ける
# routeは複数指定も可能、methodsはリストなので複数指定可能
@sensor_blueprint.route('/list', methods=['GET'])
def list_sensor():
    # クエリーパラメータ取得 request.args.get
    # 第一引数:パラメータ名、default=で初期値、type=で変換する型を指定できる
    q_limit = request.args.get('limit', default=-1, type=int)
    q_offset = request.args.get('offset', default=0, type=int)

    sensors = {
        'id': 1,
        'name': 'Fuel',
        'type': 'Fuel',
        'location': 'Front_B1',
        'status': 'activate'
    }

    # jsonレスポンス返却
    # jsonifyにdict型オブジェクトを設定するとjsonデータのレスポンスが生成される
    return jsonify(sensors), 200

# エラーのハンドリング errorhandler(xxx)を指定、複数指定可能
# ここでは400,404をハンドリングする
@app.errorhandler(400)
@app.errorhandler(404)
def error_handler(error):
    # error.code: HTTPステータスコード
    # error.description: abortで設定したdict型
    return jsonify({'error': {
        'code': error.description['code'],
        'message': error.description['message']
    }}), error.code